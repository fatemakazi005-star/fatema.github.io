# Images Folder

Place your images here before uploading to GitHub.

## Required Images

| File | Description |
|------|-------------|
| `profile.jpg` | Your profile photo (recommended: 400×480px) |
| `proj1.png` | Screenshot of Ai4A project |
| `proj2.png` | Screenshot of Design Thinking project |
| `proj3.png` | Screenshot of ACE project |

## Gallery Images (place in `gallery/` subfolder)

| File | Description |
|------|-------------|
| `gallery/grad.jpg` | Graduation or college photo |
| `gallery/award.jpg` | Best Student Award photo |
| `gallery/cert_coursera.jpg` | Scanned Coursera certificate |
| `gallery/cert_netcad.jpg` | Scanned Netcad certificate |
| `gallery/cert_yuva.jpg` | Scanned Yuva AI certificate |
| `gallery/hackathon.jpg` | Hackathon team photo |
| `gallery/techfest.jpg` | Tech Fest trophy/photo |
| `gallery/workshop.jpg` | Workshop or event photo |

## Tips
- Keep file sizes under 500KB for fast loading
- Use JPG for photos, PNG for screenshots
- Recommended dimensions: 800×600px for gallery, 1200×800px for projects
